from helper import *

def cluster_distance(c1, c2, data, method='min'):
    distances = []
    for i in c1:
        for j in c2:
            distances.append(euclidean(data[i], data[j]))
    if method == 'min':
        return min(distances)
    elif method == 'max':
        return max(distances)
    elif method == 'average':
        return sum(distances) / len(distances)
    else:
        raise ValueError("Unknown linkage method")

def hierarchical_clustering(data, linkage='min'):
    clusters = [[i] for i in range(len(data))]

    while len(clusters) > 4:
        min_dist = float('inf')
        to_merge = (None, None)
        for i in range(len(clusters)):
            for j in range(i + 1, len(clusters)):
                dist = cluster_distance(clusters[i], clusters[j], data, method=linkage)
                if dist < min_dist:
                    min_dist = dist
                    to_merge = (i, j)
        i, j = to_merge
        merged = clusters[i] + clusters[j]
        clusters = [clusters[k] for k in range(len(clusters)) if k not in [i, j]]
        clusters.append(merged)

    return clusters

def print_merge_history(merge_history, states):
    print("\nMerge History (Cluster A + Cluster B @ Distance):")
    for a, b, dist in merge_history:
        a_names = ', '.join(states[i] for i in a)
        b_names = ', '.join(states[i] for i in b)
        print(f"[{a_names}] + [{b_names}] @ distance {dist:.2f}")

def main():
    filename = "USArrests.csv"
    states, header, raw_data = load_data(filename)
    data = standardize(raw_data)
    for linkage in ['min', 'max', 'average']:
        print(f"\n--- {linkage.upper()} Linkage Clustering ---")
        clusters = hierarchical_clustering(data, linkage=linkage)
        for i, cluster in enumerate(clusters):
            print(f"\nCluster {i + 1} ({len(cluster)} states):")
            for idx in cluster:
                print(f"  - {states[idx]}")




if __name__ == "__main__":
    main()
