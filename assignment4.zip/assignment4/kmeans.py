from helper import *
import random

def assign_clusters(data, centroids):
    clusters = [[] for _ in centroids]
    for point in data:
        distances = [euclidean(point,centroid) for centroid in centroids]
        cluster_index = distances.index(min(distances))
        clusters[cluster_index].append(point)
    return clusters

def compute_centroids(clusters):
    new_centroids = []
    for cluster in clusters:
        if len(cluster) == 0:
            continue
        transposed = list(zip(*cluster))
        centroid = [mean(dim) for dim in transposed]
        new_centroids.append(centroid)
    return new_centroids

def k_means(data, k=4, max_iters=100, tol=1e-4):
    centroids = random.sample(data, k)
    for _ in range(max_iters):
        clusters = assign_clusters(data, centroids)
        new_centroids = compute_centroids(clusters)
        if all(euclidean(a, b) < tol for a, b in zip(centroids, new_centroids)):
            break
        centroids = new_centroids
    labels = []
    for point in data:
        distances = [euclidean(point, c) for c in centroids]
        labels.append(distances.index(min(distances)))
    return labels, centroids

def describe_clusters(labels, states, header, data):
    cluster_data = {}
    for i, label in enumerate(labels):
        cluster_data.setdefault(label, {"data": [], "states": []})
        cluster_data[label]["data"].append(data[i])
        cluster_data[label]["states"].append(states[i])

    for label, content in cluster_data.items():
        members = content["data"]
        state_names = content["states"]
        transposed = list(zip(*members))

        print(f"\nCluster {label}:")
        for i, attr in enumerate(transposed):
            print(f"  {header[i]} avg: {mean(attr):.2f}")

        print(f"  States in cluster {label}:")
        for state in state_names:
            print(f"\t- {state}")

def main():
    filename = "USArrests.csv"
    states, header, data = load_data(filename)
    standardized_data = standardize(data)
    labels, centroids = k_means(standardized_data, k=4)
    describe_clusters(labels, states, header, data)



if __name__ == "__main__":
    main()
