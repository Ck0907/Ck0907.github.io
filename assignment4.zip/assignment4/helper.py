import csv
import math

def load_data(filename):
    states = []
    data = []
    with open(filename, 'r') as file:
        reader = csv.reader(file)
        header = next(reader)[1:]
        for row in reader:
            states.append(row[0])
            values = list(map(float, row[1:]))
            data.append(values)
    return states, header, data

def standardize(data):
    transposed = list(zip(*data))
    standardized = []
    for col in transposed:
        mu = mean(col)
        sigma = math.sqrt(sum((x-mu)**2 for x in col)/len(col))
        standardized.append([(x-mu)/sigma for x in col])
    return list(map(list, zip(*standardized)))

def mean(values):
    return sum(values) / len(values)

def euclidean(p, q):
    return math.sqrt(sum((a - b)**2 for a, b in zip(p, q)))